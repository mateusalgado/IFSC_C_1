#include <stdio.h>
#include <locale.h>
/* *****************************************************
* Autor: Leonardo Gabriel Muraro Beche                 *
* Este programa solicita senha para acessar o ambiente *
***************************************************** */
int main()
{
    setlocale(LC_CTYPE, "");
    char senha[7], desbloc[13];
    unsigned int i=0;
    while (1)
    {
        if(i<3)
        {
            printf("Infome a senha de acesso: ");
            scanf("%8[^\n]s",senha);
            fflush(stdin);
            if(strcmp(senha,"M1abd!")==0)
            {
                printf("ACESSO PERMITIDO \n");
            }
            else
            {
                printf("ACESSO NEGADO \n");
                i++;
            }
        }
        else
        {
            printf("ACESSO BLOQUEADO \n");
            printf("Infome a senha de desbloqueio: ");
            scanf("%14[^\n]s",desbloc);
            fflush(stdin);
            if(strcmp(desbloc,"Ax64@28uRt*q")==0)
            {
                printf("ACESSO DESBLOQUEADO \n");
                i=0;
            }
        }
    }
    return 0;
}
