#include <stdio.h>
#include <locale.h>
/* *********************************************************************************************
* Autor: Leonardo Gabriel Muraro Beche                                                         *
* Este programa reponde aos comandos de um menu para quest�es relacionadas ao plano cartesiano *
********************************************************************************************** */
int main()
{
    setlocale(LC_CTYPE, "");
    float x, y, dist;
    char caso;
    int n, i=1;
    while (i==1)
    {
        printf("MENU\n");
        printf("<a> Informe as coordenadas do ponto no sistema cartesiano (x e y).\n");
        printf("<b> Localize o ponto no sistema cartesiano: quadrante (1�, 2�, 3� ou 4�), eixo (x ou y) ou origem (0,0).\n");
        printf("<c> Informe a dist�ncia do ponto em rela��o a origem.\n");
        printf("<d> Limpa a tela.\n");
        printf("<e> Encerrar o programa.\n");
        printf("Op��o: ");
        fflush(stdin);
        caso=tolower(getchar());
        switch (caso)
        {
        case 'a':
            printf("Coordenadas: ");
            scanf("%f %f", &x, &y);
            break;
        case 'b':
            printf("Localiza��o: ");
            if(x==0){
                if(y==0)
                    printf("Origem (0,0)\n");
                else
                    printf("Eixo y\n");
            }
            else if(x>0)
            {
                if(y==0)
                    printf("Eixo x\n");
                else if(y>0)
                    printf("Primeiro quadrante\n");
                else if(y<0)
                    printf("Quarto quadrante\n");
            }
            else if(x<0)
            {
                if(y==0)
                    printf("Eixo x\n");
                else if(y>0)
                    printf("Segundo quadrante\n");
                else if(y<0)
                    printf("Terceiro quadrante\n");
            }
            break;
        case 'c':
            dist= sqrt(x*x+y*y);
            printf("A dist�ncia da origem �: %0.2f \n",dist);
            break;
        case 'd':
            system("cls");
            break;
        default:
            printf("*** PROGRAMA ENCERRADO ***\n");
            i=0;
        }
    }
    return 0;
}
