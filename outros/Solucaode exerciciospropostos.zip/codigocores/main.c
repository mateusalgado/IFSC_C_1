#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

void Valor(int*);
int Menu(int);
int main()
{
    int i=0;
    int faixas[4],inf,sup;
    setlocale(LC_CTYPE,"");
   do
    {
        while(i<4)
        {
            faixas[i] = Menu(i);
            if(i==0)
            {
                inf=1;
                sup=9;
            }
            else if(i==1)
                inf=0;
            else if(i==2)
            {
                inf=-2;
                sup=6;
            }
            else
                sup=-1;
            //se esta na �ltima faixa e est� certo pode sair
            if(i==3&&faixas[i]==2)
                break;
            if(faixas[i]<inf || faixas[i]>sup )
            {
                printf("Erro na faixa %d\n ",i+1);
                continue;
            }
            i++;
        }
        Valor(faixas);
        printf("\nDigite 0 para sair ou outro numero para continuar: ");
        scanf("%d",&sup);
        system("cls");
        i=0;
    }while(sup!=0);

    return 0;
}

void Valor(int* pt)
{
#include <math.h>
    int dezena;
    dezena = (10*pt[0]+pt[1]);
    if(pt[2]<2)
        printf("Valor do resistor = %.2f\n",dezena*pow(10,pt[2]));
    else if(pt[2]==2)
        printf("Valor do resistor = %d k\n",dezena/10);
    else if(pt[2]==3)
        printf("Valor do resistor = %d k\n",dezena);
    else if(pt[2]==4)
        printf("Valor do resistor = %d k\n",dezena*10);
    else if(pt[2]==5)
        printf("Valor do resistor = %d M\n",dezena/10);
    else
        printf("Valor do resistor = %d M\n",dezena);
    if(pt[3]==-1)
        printf("Toler�ncia = 5%%\n");
    else if(pt[3]==-2)
        printf("Toler�ncia = 10%%\n");
    else
        printf("Toler�ncia = 2%%\n");
}

int Menu(int i)
{
    int retorno;
    printf("\t\tCores:\n<0>preto    <1>marrom  <2>vermelho <3>laranja\n");
    printf("<4>amarelo  <5>verde   <6>azul     <7>roxo\n");
    printf("<8>cinza    <9>branco  <-1>ouro    <-2>prata\n\n");
    printf("Entre com a cor da faixa %d: ",i+1);
    scanf("%d",&retorno);
    system("cls");
    return retorno;
}
